INVENTARIO NEGOCIO - ANDROID

Esta carpeta contiene la aplicación web lista para empaquetarse como una app Android.

IMPORTANTE:
No puedo generar aquí un APK firmado/instalable directamente con el SDK de Android, porque este entorno no incluye el proceso completo de compilación y firma de Android.

La aplicación sí está completa como app web local. Para convertirla en APK se puede envolver con Android WebView/Capacitor y generar el APK.

Archivos:
- index.html: aplicación
- styles.css: diseño
- app.js: inventario y almacenamiento local
- manifest.json: configuración PWA

La app guarda los datos localmente mediante IndexedDB.
